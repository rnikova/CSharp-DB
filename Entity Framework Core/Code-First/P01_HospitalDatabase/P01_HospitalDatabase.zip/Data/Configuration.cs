﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=Hospital;Integrated Security=true;";
    }
}
