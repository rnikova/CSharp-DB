﻿namespace P03_FootballBetting.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=WRITEME;Integrated Security=true;";
    }
}
