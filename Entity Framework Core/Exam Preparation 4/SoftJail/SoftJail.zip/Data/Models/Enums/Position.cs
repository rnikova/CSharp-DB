﻿namespace SoftJail.Data.Models.Enums
{
    public enum Position
    {
        Overseer = 0,
        Guard = 1,
        Watcher = 2,
        Labour = 3
    }
}
